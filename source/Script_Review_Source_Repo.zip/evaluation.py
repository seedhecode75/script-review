"""Type-level regression fixtures, not a benchmark of general cliffhanger quality."""
import json
from pathlib import Path
from inputs import plain_episode,validate_episode
from pipeline import run_project
from backend import save_json
from reports import export_run

CASES=[
    dict(id=101,title='Pending offer',text='Commander Vale offers Ren command of the rescue team.\nRen studies the insignia in silence.\nThe scene ends before Ren responds.',expected=['decision']),
    dict(id=102,title='Offer refused',text='Commander Vale asks Ren to lead the rescue team.\nRen says: No. I refuse the position.\nVale accepts the refusal and leaves.',expected=[]),
    dict(id=103,title='Identity clue',text='A courier reports that a traveler has the same crescent birthmark as the missing Queen Selene.\nThe guard asks: Is it really the queen?\nThe courier says: I do not know. We have only that clue.',expected=['identity']),
    dict(id=104,title='Identity confirmed',text='The guard wonders whether the traveler is the missing Queen Selene.\nThe narrator states: The traveler is Queen Selene, alive after her disappearance.\nShe reveals her face to the guard.',expected=[]),
    dict(id=105,title='Immediate threat',text='Pilot Asha is trapped inside a damaged aircraft.\nFuel ignites outside. The exit is jammed.\nAsha pulls at the handle as the flames approach. Cut to black.',expected=['danger']),
    dict(id=106,title='Threat resolved',text='Pilot Asha is trapped inside a burning aircraft.\nShe forces open the door and escapes to a safe distance.\nThe narrator confirms that Asha is safe and uninjured.',expected=[]),
    dict(id=107,title='Quiet ending',text='Nila finishes her tea after a peaceful afternoon.\nHer brother puts away the cups.\nThey admire the sunset and say goodnight.',expected=[]),
    dict(id=108,title='Answer earlier in episode',text='Ren tells Vale: I accept command of the rescue team.\nThe narrator confirms that Ren has accepted the role.\nA photograph of the original offer lies on the desk.\nRen studies the photograph silently as the scene fades.',expected=[]),
]

def demo_episodes():
    return [validate_episode(plain_episode(c['text'],c['id'],c['title']+'.txt')) for c in (CASES[0],CASES[2])]

def run_evaluation(backend,cfg,progress=None):
    episodes=[validate_episode(plain_episode(c['text'],c['id'],c['title']+'.txt')) for c in CASES]
    path=run_project(backend,episodes,cfg,progress)
    result=json.loads((Path(path)/'results.json').read_text());rows=[]
    for expected,ep in zip(CASES,result['episodes']):
        found=sorted(set(c['kind'] for c in ep['candidates'] if c['status']=='open_candidate'))
        unresolved=any(c['status'] in ('needs_review','processing_error') for c in ep['candidates'])
        passed=not ep['errors'] and not unresolved and found==sorted(expected['expected'])
        rows.append(dict(case=expected['title'],expected_open_kinds=expected['expected'],predicted_open_kinds=found,
                         errors=ep['errors'],needs_review=unresolved,passed=passed))
    report=dict(type_level_exact_matches=sum(r['passed'] for r in rows),total=len(rows),cases=rows,
        limitation='Original development fixtures visible in source. Category matches do not validate exact question meaning, evidence relevance, unseen shows, or payoff tracking.')
    save_json(Path(path)/'evaluation.json',report);export_run(path)
    return path,report
