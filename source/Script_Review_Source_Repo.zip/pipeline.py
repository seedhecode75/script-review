import copy, hashlib, json, re, unicodedata, time
from datetime import datetime,timezone
from pathlib import Path
from backend import save_json
from inputs import chunks

VERSION='desk-2.1'
def obj(p):return dict(type='object',properties=p,required=list(p),additionalProperties=False)
def string(n):return dict(type='string',maxLength=n)
def enum(values):return dict(type='string',enum=values)
def ids_schema(blocks):return dict(type='array',items=enum([b['id'] for b in blocks]),maxItems=3)
def render(blocks):return '\n'.join(f"[{b['id']}] {b['label']}: {b['text']}" for b in blocks)
def check_ids(ids,blocks,required=True):
    if required and not ids:raise ValueError('Missing supporting evidence')
    if len(set(ids))!=len(ids) or set(ids)-{b['id'] for b in blocks}:raise ValueError('Invalid or duplicate evidence IDs')

def question_for(item):
    subject=unicodedata.normalize('NFKC',item['subject']).strip(' ?')
    predicate=unicodedata.normalize('NFKC',item['predicate']).strip(' ?')
    if not subject or not predicate:raise ValueError('Empty subject or predicate')
    q=f"{'Is' if item['kind']=='identity' else 'Will'} {subject} {predicate}?"
    if '?' in subject+predicate or re.search(r'\b(and|or)\s+(who|what|why|how|will|is|does|can)\b',q,re.I):
        raise ValueError('Compound slot; needs editorial review')
    if re.search(r'\b(symboli[sz]|significance|emotional weight|reflect her|reflect his)',predicate,re.I):
        raise ValueError('Interpretive question; outside the supported hook categories')
    return q

EXTRACT='''Extract concrete unresolved story setups, NOT reading-comprehension questions.
Look at the ending and identify up to THREE items in these categories only:
decision: someone is directly asked/offered to do something, with a response to determine.
identity: specific clues suggest that person X may be person Y; unnamed people alone do not qualify.
danger: an explicit immediate threat is introduced, with survival/prevention/escape to determine.
Ignore symbolism, emotional analysis, broad motives, generic future consequences and facts already narrated.
For a decision/danger, predicate must be a base-form verb phrase suitable after "Will SUBJECT ...?".
For identity, predicate must be the hypothesized identity suitable after "Is SUBJECT ...?".
Do not put a question into either slot. One information need per item.
state_at_end is open, closed, or unclear. State closed if this ending itself resolves it.
setup_ids cite the offer/clue/threat. answer_ids cite an actual response, if shown; otherwise [].
Examples (unrelated fictional examples, not answers for the supplied script):
An officer offers Ren command; silence follows -> decision, Ren, accept command, open.
Ren says "No, I refuse" -> same decision, closed, cite refusal.
A traveler has the missing queen's birthmark, no confirmation -> identity, the traveler, the missing queen, open.
A trapped pilot hears an explosion as the door jams -> danger, the pilot, escape the aircraft, open.
A person smiles at sunset; nothing pending -> items: [].
Use only the supplied passages. Return fewer than three, including zero, when appropriate.'''

VERIFY='''Check the proposed setup and question against the supplied script excerpt.
The setup passages are repeated to make the question understandable; the excerpt is one part of the FULL episode.
support: supported if the actual offer, identity clue, or concrete threat exists; unsupported if invented; unclear if ambiguous.
resolution: answered ONLY if dialogue or unambiguous action answers this precise question;
unanswered if no answer is shown in this excerpt; unclear if it is ambiguous.
A refusal answers a decision with No. A smile alone does not establish acceptance.
IMPORTANT: support concerns whether the QUESTION has a concrete setup, NOT whether its answer is true.
A rumor with a specific resemblance or matching scar supports an identity QUESTION, even if the speaker says "I do not know".
Such a clue does NOT answer the identity question: use support=supported, resolution=unanswered unless an actual answer appears.
An unnamed stranger alone, without a specific identity hypothesis or clue, is not an identity setup.
Do not mark support unclear solely because the outcome or identity is unknown.
An explicit narrator identification can answer identity. A warning does not show its outcome.
For answered, give a SHORT actual answer and answer_polarity yes/no/other; cite the answer itself.
Otherwise answer must be empty and answer_polarity none; cite relevant evidence if present.
Do not infer answers from typical story patterns. Keep reason to one short sentence.'''

def extract(backend,blocks,cfg,run_dir,label):
    schema=obj({'items':dict(type='array',maxItems=3,items=obj({
        'kind':enum(['decision','identity','danger']),'subject':string(80),'predicate':string(140),
        'state_at_end':enum(['open','closed','unclear']),
        'setup_ids':ids_schema(blocks),'answer_ids':ids_schema(blocks)}))})
    result=backend.structured(EXTRACT,{'ending':render(blocks)},schema,label,run_dir)
    for item in result['items']:
        check_ids(item['setup_ids'],blocks)
        check_ids(item['answer_ids'],blocks,False)
    return result['items']

def aggregate(verdicts):
    if not verdicts:return dict(status='needs_review',answer='',reason='No verification completed')
    if any(v['support']=='unclear' or v['resolution']=='unclear' for v in verdicts):
        return dict(status='needs_review',answer='',reason='Ambiguous evidence in at least one excerpt')
    supports={v['support'] for v in verdicts}
    if supports=={'unsupported'}:return dict(status='unsupported',answer='',reason='Setup was not supported')
    if 'unsupported' in supports:return dict(status='needs_review',answer='',reason='Verification disagrees about the setup')
    answers=[v for v in verdicts if v['resolution']=='answered']
    if answers:
        polarities={v['answer_polarity'] for v in answers}
        if len(polarities)>1 or ('other' in polarities and len({v['answer'].lower().strip() for v in answers})>1):
            return dict(status='needs_review',answer='',reason='Different answers across excerpts; inspect chronology')
        return dict(status='resolved_in_episode',answer=answers[-1]['answer'],reason='An answer was found in the full episode')
    return dict(status='open_candidate',answer='',reason='Supported setup; no answer found in the supplied episode. Editorial review required.')

def analyze_episode(backend,ep,cfg,run_dir):
    original=[b for b in ep['blocks'] if b.get('kind')!='sound']
    if not original:raise ValueError('No story-bearing passages')
    mapping={f'B{i:03d}':b['id'] for i,b in enumerate(original,1)}
    blocks=[dict(b,id=k) for k,b in zip(mapping,original)]
    if ep['format']=='timed':ending=[b for b in blocks if b['end']>=ep['duration']-cfg['ending_seconds']]
    else:ending=blocks[-cfg['plain_ending_blocks']:]
    result=dict(episode_id=ep['episode_id'],filename=ep['filename'],format=ep['format'],duration=ep['duration'],
                id_map=mapping,candidates=[],errors=[],ending_ids=[mapping[b['id']] for b in ending])
    items=extract(backend,ending,cfg,run_dir,f"E{ep['episode_id']:03d}_extract")
    parts=chunks(blocks,cfg['verification_chunk_chars'])
    if len(parts)>cfg['max_verification_chunks']:raise ValueError('Episode too long for configured verification budget; no incomplete verification accepted')
    seen=set()
    for i,item in enumerate(items):
        record=dict(candidate_id=f"E{ep['episode_id']:03d}_H{i+1}",kind=item['kind'],
                    subject=item['subject'],predicate=item['predicate'],proposal_state=item['state_at_end'],
                    setup_ids=[mapping[x] for x in item['setup_ids']],question='',
                    status='needs_review',answer='',reason='',verification=[],coverage_complete=False)
        try:
            record['question']=question_for(item)
            if record['question'].casefold() in seen:continue
            seen.add(record['question'].casefold())
            setup=[b for b in blocks if b['id'] in item['setup_ids']]
            checks=[]
            for j,part in enumerate(parts):
                context=list({b['id']:b for b in setup+part}.values())
                schema=obj({'support':enum(['supported','unsupported','unclear']),
                    'resolution':enum(['answered','unanswered','unclear']),
                    'answer_polarity':enum(['yes','no','other','none']),'answer':string(180),
                    'evidence_ids':ids_schema(context),'reason':string(240)})
                value=backend.structured(VERIFY,{'question':record['question'],'kind':item['kind'],
                    'setup':render(setup),'excerpt':render(part),'excerpt_number':j+1,'total_excerpts':len(parts)},
                    schema,f"{record['candidate_id']}_verify_{j+1}",run_dir)
                check_ids(value['evidence_ids'],context,value['resolution']=='answered')
                if value['resolution']=='answered':
                    if not value['answer'].strip() or value['answer_polarity']=='none':raise ValueError('Answered without an actual answer')
                elif value['answer'].strip() or value['answer_polarity']!='none':raise ValueError('Non-answered result contains an answer')
                value['evidence_ids']=[mapping[x] for x in value['evidence_ids']]
                for key in ('answer','reason'):
                    value[key]=re.sub(r'\bB\d{3,}\b',lambda m:mapping.get(m.group(),m.group()),value[key])
                checks.append(value)
            record.update(aggregate(checks));record['verification']=checks;record['coverage_complete']=True
        except Exception as ex:
            record.update(status='processing_error',reason=str(ex));result['errors'].append(str(ex))
        result['candidates'].append(record)
    return result

def run_project(backend,episodes,cfg,progress=None):
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%f')
    out=Path(cfg['output_root'])/stamp;out.mkdir(parents=True)
    started=time.monotonic()
    save_json(out/'config.json',dict(cfg,pipeline_version=VERSION))
    save_json(out/'parsed_episodes.json',episodes)
    source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')}
    save_json(out/'source_hashes.json',source_hashes)
    result=dict(run_id=stamp,pipeline_version=VERSION,created_utc=stamp,episodes=[],status='running')
    for i,ep in enumerate(episodes):
        if progress:progress(i,len(episodes),f"Reviewing episode {ep['episode_id']}")
        try:row=analyze_episode(backend,ep,cfg,out)
        except Exception as ex:row=dict(episode_id=ep['episode_id'],filename=ep['filename'],candidates=[],errors=[str(ex)])
        result['episodes'].append(row);save_json(out/'results.json',result)
    result['wall_seconds']=round(time.monotonic()-started,2)
    result['error_count']=sum(len(e['errors']) for e in result['episodes'])
    result['status']='completed_with_errors' if result['error_count'] else 'completed'
    result['notice']='Model proposals, not approved editorial labels. No retention or engagement prediction; no cross-episode payoff tracking.'
    save_json(out/'results.json',result)
    save_json(out/'human_reviews.json',{})
    from reports import export_run
    export_run(out)
    if progress:progress(len(episodes),len(episodes),'Ready for editorial review')
    return str(out)
