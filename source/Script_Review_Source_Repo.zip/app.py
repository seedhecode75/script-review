"""Gradio review workspace; lazy GPU loading and a single inference queue."""
import argparse,html,json,os,threading,time,queue,re
from pathlib import Path
import gradio as gr
from backend import QwenBackend
from inputs import load_inputs,dataset_paths
from pipeline import run_project
from reports import (load_run,candidate_rows,dashboard_html,evidence_html,
                     store_review,add_manual,export_run)
from evaluation import CASES,run_evaluation
from hard_cases import HARD_CASES
DEMOS=CASES+HARD_CASES

CSS='''
.gradio-container {max-width:1240px!important;margin:auto!important;font-family:ui-sans-serif,system-ui,sans-serif!important;background:#0c1421!important;color:#e4edf6!important;padding:24px!important;--body-background-fill:#0c1421;--block-background-fill:#121e2f;--input-background-fill:#0c1727;--body-text-color:#e4edf6;--block-label-background-fill:transparent;--block-label-text-color:#aabbd0}
#hero {padding:32px;border:1px solid #2b4058;border-radius:18px;background:linear-gradient(125deg,#152940,#102031 65%,#123c43);margin-bottom:18px}
#hero small {font-size:11px;letter-spacing:2.5px;color:#68ded2;font-weight:700}
#hero h1 {font-size:44px!important;letter-spacing:-1.7px!important;line-height:1.15!important;color:#f5f9ff!important;margin:12px 0!important}
#hero p {color:#b1c3d6!important;max-width:680px;font-size:16px;line-height:1.7}
.sr-tag {display:inline-block;border:1px solid #3b6571;padding:5px 11px;border-radius:20px;font-size:11px;letter-spacing:1px;color:#8ce6db;margin-top:8px}
.gradio-container .block {background:#121e2f!important;border-color:#293c53!important;border-radius:12px!important}
.gradio-container label span,.gradio-container .label-wrap {background:transparent!important;color:#b4c5d8!important}
.gradio-container textarea,.gradio-container input:not([type=range]) {background:#0c1727!important;color:#e6eff9!important;border-color:#30455d!important}
.gradio-container button.primary {background:#62d6c7!important;color:#062b2a!important;border:0!important;font-weight:750!important;box-shadow:none!important}
.gradio-container button.secondary {background:#1c3047!important;color:#dfebf7!important;border-color:#37506a!important}
.gradio-container .tab-nav {border-color:#2c4056!important;margin:18px 0!important}
.gradio-container .tab-nav button {color:#9fb4cb!important;padding:12px 20px!important}
.gradio-container .tab-nav button.selected {color:#79e2d5!important;border-color:#62d6c7!important}
.evidence {border:1px solid #324a62;border-left:3px solid #62d6c7;background:#0f2032;padding:14px 18px;margin:12px 0;border-radius:0 10px 10px 0}
.evidence small {color:#78d8d1!important;font-weight:650;font-size:12px}
.evidence p {margin:9px 0 2px!important;color:#e5eef9!important;line-height:1.75!important}
.sr-metrics {display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}
.sr-metric {padding:20px;border:1px solid #2e435b;border-radius:12px;background:#132238;color:#adc0d6}
.sr-metric strong {display:block;color:#f1f7ff;font-size:29px;font-weight:650;margin-bottom:6px}
.sr-metric span {font-size:12px;letter-spacing:.4px}
@media(max-width:680px){.sr-metrics{grid-template-columns:repeat(2,1fr)}#hero{padding:22px}#hero h1{font-size:34px!important}.gradio-container{padding:12px!important}}
'''

def make_app(cfg,backend=None,public_demo=False):
    backend=backend or QwenBackend(cfg);lock=threading.Lock()
    def load_view(path):
        result,episodes,reviews=load_run(path);rows=candidate_rows(result,reviews)
        choices=[(f"E{r['episode']} · {r['question'] or r['candidate_id']}",r['candidate_id']) for r in rows]
        table=[[r[k] for k in ('episode','kind','question','model_status','editor_decision')] for r in rows]
        timing=json.loads((Path(path)/'run_metrics.json').read_text())
        message=f"{result['status']} · {len(episodes)} episodes · {timing['generation_calls']} model calls · {timing['generation_seconds']:.1f}s generation time"
        if result.get('error_count'):message+='\nErrors: '+'; '.join(error for e in result['episodes'] for error in e['errors'])
        return (path,dashboard_html(result,reviews),table,
                gr.update(choices=choices,value=None),gr.update(choices=[str(e['episode_id']) for e in episodes],value=str(episodes[0]['episode_id'])),
                message,str(Path(path)/'review.html'),str(Path(path))+'.zip')

    def analyze(files,text,count,seconds,source,selected_ids='',notify=lambda message:None):
        run_cfg=dict(cfg,ending_seconds=int(seconds),max_episodes=int(count))
        try:
            if source=='dataset':episodes=load_inputs(dataset_paths(cfg['input_dir']),limit=int(count),episode_ids=cfg['episode_ids'])
            else:
                ids=[int(n) for n in re.split(r'[,\s]+',selected_ids.strip()) if n] if selected_ids.strip() else None
                episodes=load_inputs(files,text,limit=int(count),episode_ids=ids)
            notify('Parsed episodes: '+', '.join(str(e['episode_id']) for e in episodes))
            with lock:
                backend.on_status=notify
                try:path=run_project(backend,episodes,run_cfg,lambda i,n,s:notify(f'{s} ({i}/{n} complete)'))
                finally:backend.on_status=None
            return load_view(path)
        except Exception as ex:raise gr.Error(str(ex))

    def stream_analyze(files,text,count,seconds,selected_ids,source):
        # Work in a thread so the UI receives elapsed-time updates even while weights load.
        events=queue.Queue();started=time.monotonic();current='Validating inputs'
        def work():
            try:
                output=analyze(files,text,count,seconds,source,selected_ids,lambda m:events.put(('stage',m)))
                events.put(('done',output))
            except Exception as ex:events.put(('error',str(ex)))
        threading.Thread(target=work,daemon=True).start()
        while True:
            try:kind,value=events.get(timeout=1)
            except queue.Empty:kind,value='stage',current
            if kind=='done':
                output=list(value);output[5]+=f" · {time.monotonic()-started:.1f}s request time (includes loading if needed)"
                yield tuple(output);return
            if kind=='error':raise gr.Error(value)
            current=value
            output=[gr.skip() for _ in range(8)]
            output[5]=f"{current}\nElapsed: {time.monotonic()-started:.0f}s. Please do not click Analyze again."
            yield tuple(output)

    def stream_upload(files,text,count,seconds,ids):
        yield from stream_analyze(files,text,count,seconds,ids,'upload')

    def stream_dataset(count,seconds):
        yield from stream_analyze(None,'',count,seconds,'','dataset')

    def selected(path,cid):
        if not path or not cid:return '', 'needs_review','', '<p>Select a question.</p>'
        result,episodes,reviews=load_run(path)
        row=next(r for r in candidate_rows(result,reviews) if r['candidate_id']==cid)
        ep=next(e for e in episodes if e['episode_id']==row['episode'])
        original=next((c for e in result['episodes'] for c in e['candidates'] if c['candidate_id']==cid),None)
        details='<h3>Setup evidence</h3>'+evidence_html(row['setup_ids'].split('; '),ep['blocks'])
        if original:
            details+=f"<p><b>Model judgment:</b> {html.escape(original['status'])}<br>{html.escape(original['reason'])}</p>"
            ids=list(dict.fromkeys(i for v in original['verification'] for i in v['evidence_ids']))
            details+='<h3>Verification evidence</h3>'+evidence_html(ids,ep['blocks'])
            if original['answer']:details+='<p><b>Answer found:</b> '+html.escape(original['answer'])+'</p>'
        return row['question'],row['editor_decision'] if row['editor_decision']!='unreviewed' else 'needs_review',row['notes'],details

    def save(path,cid,question,decision,notes):
        if not path or not cid:raise gr.Error('Analyze a script and select a question first.')
        try:store_review(path,cid,question,decision,notes);return load_view(path)
        except Exception as ex:raise gr.Error(str(ex))

    def add(path,episode,kind,question,ids,notes):
        if not path:raise gr.Error('Analyze a script first.')
        try:add_manual(path,int(episode),kind,question,ids,notes);return load_view(path)
        except Exception as ex:raise gr.Error(str(ex))

    def show_episode(path,episode):
        if not path or episode is None:return ''
        _,episodes,_=load_run(path);ep=next(e for e in episodes if e['episode_id']==int(episode))
        return evidence_html([b['id'] for b in ep['blocks']],ep['blocks'])

    def evaluate(progress=gr.Progress()):
        with lock:path,report=run_evaluation(backend,cfg,lambda i,n,s:progress((i,n),desc=s))
        return report,str(Path(path))+'.zip'

    with gr.Blocks(title='Script Review',theme=gr.themes.Soft(primary_hue='teal',neutral_hue='slate'),css=CSS) as app:
        state=gr.State('')
        gr.HTML("<div id='hero'><small>SCRIPT REVIEW / EDITOR WORKSPACE</small><h1>Script Review</h1><p>Find the question that keeps the story moving. Review unresolved moments, trace the evidence, and make the final call.</p><span class='sr-tag'>EVIDENCE FIRST · EDITOR APPROVED</span></div>")
        gr.Markdown('A review workspace for episode endings. Every AI proposal stays provisional until you review it.')
        if public_demo:
            gr.Markdown('**Public demo:** Use only original fictional or otherwise public scripts. Do not upload confidential Kuku/customer scripts. Files and raw model calls may be accessible to the demo operator.')
        summary=gr.HTML(dashboard_html({'episodes':[]},{}))
        with gr.Tab('1 · Analyze'):
            with gr.Row():
                with gr.Column(scale=3):
                    files=gr.File(label='Upload scripts',file_types=['.txt','.zip','.json'],file_count='multiple',type='filepath')
                    text=gr.Textbox(label='Or paste a screenplay',lines=8,placeholder='Dialogue and actions, one passage per line. Timed screenplay TXT files are also supported.')
                    fixture=gr.Dropdown(choices=[c['title'] for c in DEMOS],value=CASES[0]['title'],label='Demo library · standard + challenge cases')
                    demo=gr.Button('Load demo text')
                    demo.click(lambda name:next(c['text'] for c in DEMOS if c['title']==name),fixture,text,api_name=False)
                with gr.Column(scale=2):
                    selected_ids=gr.Textbox(label='Uploaded episode IDs (optional)',placeholder='3,9 — blank selects the first episodes')
                    count=gr.Slider(1,50,value=2,step=1,label='Maximum episodes for this run')
                    seconds=gr.Slider(15,90,value=45,step=5,label='Ending window, seconds (timed scripts)')
                    gr.Markdown('Plain text uses the last 12 non-empty lines. Verification reads the whole episode in chunks. For large inputs, start with two episodes.')
                    run=gr.Button('Analyze uploaded / pasted scripts',variant='primary')
                    dataset=gr.Button('Analyze attached Kaggle dataset',visible=not public_demo)
                    gr.Markdown('For the ten-episode ZIP: leave pasted text empty, enter 3,9 above, keep Maximum episodes at 2, then Analyze uploaded / pasted scripts. First inference loads the model; later app requests reuse it.')
            status=gr.Textbox(label='Run status',interactive=False,lines=3)
            table=gr.Dataframe(headers=['Episode','Kind','Question','Model status','Editor decision'],interactive=False,wrap=True)
        with gr.Tab('2 · Editorial desk'):
            selector=gr.Dropdown(label='Choose a proposal',choices=[])
            with gr.Row():
                with gr.Column():
                    question=gr.Textbox(label='Question to review',lines=2)
                    decision=gr.Radio(['approved','rejected','needs_review'],value='needs_review',label='Your decision')
                    notes=gr.Textbox(label='Review notes',lines=3)
                    save_button=gr.Button('Save editorial review',variant='primary')
                with gr.Column():detail=gr.HTML('<p>Select a proposal to inspect its evidence.</p>')
            with gr.Accordion('Inspect full episode / add a missed hook',open=False):
                episode=gr.Dropdown(label='Episode',choices=[])
                full=gr.HTML()
                kind=gr.Dropdown(['decision','identity','danger','other'],value='decision',label='Hook category')
                manual_question=gr.Textbox(label='Missed question')
                manual_ids=gr.Textbox(label='Supporting passage IDs, separated by commas')
                manual_notes=gr.Textbox(label='Why this hook matters')
                manual=gr.Button('Add human-identified hook')
            with gr.Row():
                html_file=gr.File(label='Download standalone review report')
                zip_file=gr.File(label='Download complete run: JSON, CSV, logs and reviews')
            gr.Markdown('The run ZIP includes review.csv (all proposals) and episode_summary.csv (including episodes with zero proposals). human_reviews.json remains empty until you save a review. The model output stays unchanged. Editorial decisions and edits are saved separately. Run archives contain input scripts; do not publish confidential archives.')
        with gr.Tab('3 · Test lab'):
            gr.Markdown('Run eight original development cases: pending/resolved offers, identity clues/confirmation, threats/escape, a quiet ending and an earlier answer. This uses GPU time. The metric checks open-hook categories, not semantic accuracy or retention.')
            gr.Markdown('**Challenge library:** Ten harder original cases are available in the Analyze demo dropdown. Use the separate CHALLENGE_RUBRIC.md to check character identity, actual resolution, and evidence. These are visible development examples, not a held-out benchmark. The button below runs the eight standard cases only.')
            eval_button=gr.Button('Run development regression suite')
            evaluation=gr.JSON(label='Measured results')
            evaluation_zip=gr.File(label='Download evaluation outputs')
        with gr.Tab('4 · About'):
            gr.Markdown('''### One editor, one review step
Script Review proposes concrete decision, identity and danger questions from episode endings. It checks the entire supplied episode for an answer and links every proposal to source passages. An editor can reject weak questions, rewrite them, or add a missed hook.

### Model and limits
Qwen3-14B runs locally in NF4 across two T4 GPUs. No fine-tuning or paid inference API is used. A thinking extraction pass produces story slots; code constructs questions; full-episode verification checks them. One constrained retry addresses invalid output. These are calls to the same model, not independent votes.

The system can miss hooks, misread implied decisions and overinterpret dialogue. A valid evidence ID does not establish that the evidence supports the claim. Zero proposals does not prove a closed ending. No cross-episode payoff tracking, automatic rewrite, or retention prediction is implemented.

### Reproducibility
Every run records configuration, source hashes, model revision, raw model calls and timing. Public demos are original fictional text; assignment scripts should remain private.''')
        outputs=[state,summary,table,selector,episode,status,html_file,zip_file]
        run.click(stream_upload,[files,text,count,seconds,selected_ids],outputs,api_name=False)
        dataset.click(stream_dataset,[count,seconds],outputs,api_name=False)
        selector.change(selected,[state,selector],[question,decision,notes,detail],api_name=False)
        save_button.click(save,[state,selector,question,decision,notes],outputs,api_name=False)
        episode.change(show_episode,[state,episode],full,api_name=False)
        manual.click(add,[state,episode,kind,manual_question,manual_ids,manual_notes],outputs,api_name=False)
        eval_button.click(evaluate,None,[evaluation,evaluation_zip],api_name=False)
        app.queue(default_concurrency_limit=1,max_size=8)
    return app

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',required=True);parser.add_argument('--share',action='store_true');parser.add_argument('--public-demo',action='store_true')
    args=parser.parse_args();cfg=json.loads(Path(args.config).read_text())
    password=os.environ.get('DESK_PASSWORD','')
    if args.share and not password and not args.public_demo:raise RuntimeError('Set DESK_PASSWORD or explicitly choose --public-demo before sharing.')
    if args.public_demo:
        # Never expose private batch output under allowed_paths. The public demo can process original/other public inputs only.
        cfg=dict(cfg,input_mode='demo',input_dir='',output_root=str(Path(cfg['output_root'])/'public_demo'))
    app=make_app(cfg,public_demo=args.public_demo)
    app.launch(server_name='0.0.0.0',server_port=7860,share=args.share,
               auth=('reviewer',password) if password else None,
               allowed_paths=[str(Path(cfg['output_root']).resolve())],show_error=True)
if __name__=='__main__':main()
