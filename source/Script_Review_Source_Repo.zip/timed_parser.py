"""Payoff Tracker: timed screenplay parser + model-driven, evidence-linked review.
No training; LLM labels are provisional, not human ground truth.
"""
import csv
import hashlib
import json
import re
import time
from pathlib import Path
from typing import Literal


VERSION = '0.3.0'

def seconds(s):
    parts = s.strip().replace(',', '.').split(':')
    if len(parts) not in (2, 3):
        raise ValueError(f'Unsupported timestamp: {s}')
    value = 0.0
    for part in parts:
        value = value * 60 + float(part)
    return round(value, 3)

def parse_episode(text, filename='input.txt'):
    match = re.search(r'^EPISODE NUMBER:\s*(?:Episode\s*)?(\d+)', text, re.M | re.I)
    if not match:
        raise ValueError(f'{filename}: missing EPISODE NUMBER header')
    number = int(match.group(1))
    body = text.split('--- SCRIPT START ---', 1)[-1].split('--- SCRIPT END ---', 1)[0]
    scenes = list(re.finditer(r'^SCENE\s+(\d+)\s*$', body, re.M))
    if not scenes:
        raise ValueError(f'{filename}: no SCENE boundaries')
    blocks, warnings = [], []
    pattern = re.compile(
        r'^\*\*(?P<label>[^\n]+?)\*\*\s*\n'
        r'Start:\s*\((?P<start>[^)]+)\)\s*\|\s*End:\s*\((?P<end>[^)]+)\)\s*\n'
        r'(?P<text>.*?)(?=^\*\*|\Z)', re.M | re.S)
    for i, scene in enumerate(scenes):
        segment = body[scene.end():scenes[i+1].start() if i+1 < len(scenes) else len(body)]
        sid = f'E{number:03d}_S{int(scene.group(1)):02d}'
        heading = re.search(r'^Scene heading:\s*(.+)$', segment, re.M)
        found = list(pattern.finditer(segment))
        labels = re.findall(r'^\*\*[^\n]+\*\*\s*$', segment, re.M)
        if len(found) != len(labels):
            raise ValueError(f'{filename}/{sid}: malformed timed blocks; refusing silent loss')
        if not found:
            raise ValueError(f'{filename}/{sid}: no timed blocks')
        for j, item in enumerate(found, 1):
            label = item['label'].rstrip(':').strip()
            kind = {'CAMERA':'camera','ACTION':'action','SOUND FX':'sound'}.get(label.upper(),'dialogue')
            speaker = re.sub(r'\s*\([^)]*\)', '', label).strip() if kind == 'dialogue' else None
            start, end = seconds(item['start']), seconds(item['end'])
            if end < start:
                raise ValueError(f'{sid}: end before start')
            blocks.append(dict(id=f'{sid}_B{j:03d}', scene_id=sid,
                               scene_heading=heading.group(1) if heading else '',
                               kind=kind, speaker=speaker, label=label,
                               start=start, end=end, text=item['text'].strip()))
    # Camera, action and speech overlap by design. Do not reject valid overlaps.
    blocks.sort(key=lambda b:(b['start'], b['end'], b['id']))
    metadata = {}
    for key in ('EPISODE LOGLINE', 'CONTINUITY NOTES'):
        value = re.search(r'^'+key+r':\s*(.+)$', text, re.M)
        metadata[key] = value.group(1) if value else ''
    return dict(episode_id=number, filename=filename, duration=max(b['end'] for b in blocks),
                blocks=blocks, editorial_metadata=metadata, warnings=warnings,
                sha256=hashlib.sha256(text.encode()).hexdigest())

def visible_blocks(ep):
    # Keep story-bearing camera shots. Sound/music is not sufficient story evidence.
    return [b for b in ep['blocks'] if b['kind'] != 'sound']

def render_blocks(blocks):
    return '\n'.join(f"[{b['id']}] {b['start']:.2f}-{b['end']:.2f}s "
                     f"{b['label']}: {b['text']}" for b in blocks)

