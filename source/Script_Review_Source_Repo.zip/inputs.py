"""Read timed screenplay TXT, plain TXT, canonical JSON, or ZIP without extraction."""
import hashlib, json, re, zipfile
from pathlib import Path
from timed_parser import parse_episode

MAX_BYTES = 25_000_000

def plain_episode(text, number, name):
    lines=[s.strip() for s in text.splitlines() if s.strip()]
    if not lines: raise ValueError(f'{name}: empty script')
    return dict(episode_id=number,filename=name,format='plain',duration=None,
        sha256=hashlib.sha256(text.encode()).hexdigest(),
        blocks=[dict(id=f'E{number:03d}_B{i:04d}',start=None,end=None,
                     label='TEXT',kind='action',text=line) for i,line in enumerate(lines,1)])

def validate_episode(ep):
    if not isinstance(ep,dict) or type(ep.get('episode_id')) is not int:
        raise ValueError('Every episode needs an integer episode_id')
    blocks=ep.get('blocks')
    if not isinstance(blocks,list) or not blocks:raise ValueError('Missing non-empty blocks list')
    seen=set()
    for b in blocks:
        if not isinstance(b,dict) or not isinstance(b.get('id'),str) or not b['id']:
            raise ValueError('Each block needs a non-empty string id')
        if b['id'] in seen:raise ValueError('Duplicate block id')
        seen.add(b['id'])
        if not isinstance(b.get('text'),str) or not b['text'].strip():raise ValueError('Empty block text')
        b.setdefault('label','TEXT');b.setdefault('kind','action')
        b.setdefault('start',None);b.setdefault('end',None)
        if (b['start'] is None)!=(b['end'] is None):raise ValueError('Partial timestamps')
        if b['start'] is not None and (not isinstance(b['start'],(int,float)) or not isinstance(b['end'],(int,float)) or b['end']<b['start'] or b['start']<0):
            raise ValueError('Invalid timestamps')
    timed=[b for b in blocks if b['start'] is not None]
    if timed and len(timed)!=len(blocks):raise ValueError('Do not mix timed and untimed blocks')
    ep['format']='timed' if timed else 'plain'
    ep['duration']=max(b['end'] for b in blocks) if timed else None
    ep.setdefault('filename',f"episode_{ep['episode_id']}.json")
    ep['sha256']=hashlib.sha256(json.dumps(blocks,sort_keys=True).encode()).hexdigest()
    return ep

def load_inputs(paths=None, text='', limit=10, episode_ids=None):
    records=[];total=0
    for source in paths or []:
        path=Path(source)
        if not path.is_file():raise ValueError(f'Missing input file: {path.name}')
        if path.stat().st_size>MAX_BYTES:raise ValueError('Input exceeds 25 MB')
        if path.suffix.lower()=='.zip':
            with zipfile.ZipFile(path) as z:
                members=[x for x in z.infolist() if not x.is_dir() and Path(x.filename).suffix.lower() in ('.txt','.json') and '__MACOSX' not in x.filename]
                if len(members)>200 or sum(x.file_size for x in members)>MAX_BYTES:raise ValueError('ZIP exceeds input limits')
                records.extend((x.filename,z.read(x)) for x in members)
        elif path.suffix.lower() in ('.txt','.json'):
            records.append((path.name,path.read_bytes()))
        else:raise ValueError('Supported uploads: TXT, JSON, ZIP')
    if text.strip():records.append(('pasted_script.txt',text.encode()))
    episodes=[]
    for name,raw in records:
        total+=len(raw)
        if total>MAX_BYTES:raise ValueError('Combined inputs exceed 25 MB')
        content=raw.decode('utf-8-sig')
        if name.lower().endswith('.json'):
            data=json.loads(content)
            if isinstance(data,dict) and 'episodes' in data:data=data['episodes']
            if isinstance(data,dict):data=[data]
            if not isinstance(data,list):raise ValueError('JSON must contain episodes')
            episodes.extend(validate_episode(e) for e in data)
        elif re.search(r'^EPISODE NUMBER:',content,re.M|re.I) and re.search(r'^SCENE\s+\d+',content,re.M):
            episodes.append(validate_episode(parse_episode(content,name)))
        else:
            number=re.search(r'(?:episode|ep)[-_\s]*(\d+)',name,re.I)
            episodes.append(validate_episode(plain_episode(content,int(number.group(1)) if number else 1000+len(episodes),name)))
    unique={}
    for ep in episodes:
        n=ep['episode_id']
        if n in unique and unique[n]['sha256']!=ep['sha256']:raise ValueError(f'Conflicting versions of episode {n}')
        unique[n]=ep
    selected=[unique[n] for n in sorted(unique) if not episode_ids or n in episode_ids]
    if episode_ids and set(episode_ids)-{e['episode_id'] for e in selected}:
        raise ValueError('Some requested episode IDs are missing; check the uploaded files')
    if not selected:raise ValueError('No scripts found. Upload TXT/ZIP, paste a script, or use the original demo.')
    return selected[:int(limit)]

def dataset_paths(root):
    return sorted(str(p) for p in Path(root).rglob('*') if p.is_file() and p.suffix.lower() in ('.txt','.json','.zip'))

def chunks(blocks, max_chars=9000):
    """Full coverage, in order. No passage truncation; one-block overlap."""
    output=[];part=[];size=0
    for b in blocks:
        n=len(b['text'])+len(b['id'])+30
        if n>max_chars:raise ValueError('A single passage exceeds the verification chunk limit; split it before running')
        if part and size+n>max_chars:
            output.append(part)
            overlap=part[-1:]
            part=overlap if len(overlap[0]['text'])+len(overlap[0]['id'])+30+n<=max_chars else []
            size=sum(len(x['text'])+len(x['id'])+30 for x in part)
        part.append(b);size+=n
    if part:output.append(part)
    return output
