import csv, html, json, shutil
from pathlib import Path
from backend import save_json

def load_run(path):
    root=Path(path)
    return (json.loads((root/'results.json').read_text()),
            json.loads((root/'parsed_episodes.json').read_text()),
            json.loads((root/'human_reviews.json').read_text()))

def candidate_rows(result,reviews):
    rows=[]
    for ep in result['episodes']:
        for c in ep['candidates']:
            review=reviews.get(c['candidate_id'],{})
            rows.append(dict(episode=ep['episode_id'],candidate_id=c['candidate_id'],kind=c['kind'],
                model_question=c['question'],model_status=c['status'],model_answer=c['answer'],
                question=review.get('question',c['question']),editor_decision=review.get('decision','unreviewed'),
                notes=review.get('notes',''),setup_ids='; '.join(c['setup_ids']),reason=c['reason']))
    for cid,review in reviews.items():
        if review.get('source')=='human_added':
            rows.append(dict(episode=review['episode_id'],candidate_id=cid,kind=review['kind'],model_question='',
                model_status='human_added',model_answer='',question=review['question'],
                editor_decision=review['decision'],notes=review['notes'],setup_ids='; '.join(review['setup_ids']),reason='Added by editor; not a model prediction'))
    return rows

def evidence_html(ids,blocks):
    by_id={b['id']:b for b in blocks};items=[]
    for identifier in ids:
        b=by_id.get(identifier)
        if not b:continue
        timing=f"{b['start']:.2f}–{b['end']:.2f}s" if b.get('start') is not None else 'untimed passage'
        items.append(f"<div class='evidence'><small>{html.escape(identifier)} · {timing}</small><p>{html.escape(b['text'])}</p></div>")
    return ''.join(items) or '<p>No evidence selected.</p>'

def dashboard_html(result,reviews):
    rows=candidate_rows(result,reviews)
    stats=[('Episodes',len(result['episodes'])),('Open proposals',sum(r['model_status']=='open_candidate' for r in rows)),
           ('Need review',sum(r['model_status'] in ('needs_review','processing_error') for r in rows)),
           ('Editor decisions',sum(r['editor_decision']!='unreviewed' for r in rows))]
    return "<div class='sr-metrics'>"+''.join(f"<div class='sr-metric'><strong>{v}</strong><span>{k}</span></div>" for k,v in stats)+"</div>"

def report_html(result,episodes,reviews):
    cards=[];lookup={e['episode_id']:e for e in episodes}
    for row in candidate_rows(result,reviews):
        cards.append(f"<article><div class='badge'>Episode {row['episode']} · {html.escape(row['kind'])} · {html.escape(row['model_status'])}</div><h2>{html.escape(row['question'])}</h2><p>{html.escape(row['reason'])}</p><p><b>Editor:</b> {html.escape(row['editor_decision'])} {html.escape(row['notes'])}</p>"+evidence_html(row['setup_ids'].split('; '),lookup[row['episode']]['blocks'])+'</article>')
    errors=''.join(f"<p>Episode {e['episode_id']}: {html.escape(error)}</p>" for e in result['episodes'] for error in e.get('errors',[]))
    return """<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Script Review | Review</title><style>body{font:16px/1.6 system-ui;margin:0;background:#f8fafc;color:#18243b}main{max-width:1000px;margin:auto;padding:36px 22px}h1{font-size:38px;margin-bottom:8px}h2{font-size:21px}article{background:white;border:1px solid #dbe3ed;border-radius:16px;margin:20px 0;padding:24px}.badge,small{color:#5b4bb7;font-weight:650}.evidence{border-left:3px solid #8b7bd6;padding:8px 18px;background:#f7f5ff;margin:12px 0}.evidence p{margin:6px 0}.notice{color:#586678}.sr-metrics{display:flex;gap:12px;flex-wrap:wrap}.sr-metric{flex:1;padding:18px;background:#edf3f7;border-radius:12px}.sr-metric strong{display:block;font-size:28px}.sr-metric span{font-size:13px}input{padding:14px;width:calc(100% - 30px);border:1px solid #ccd6e3;border-radius:10px;margin-top:24px}</style><main><div class='badge'>EDITORIAL REVIEW / CLIFFHANGER DESK</div><h1>Unfinished moments, with evidence.</h1><p class='notice'>Model proposals require editorial judgment. This report does not measure viewer engagement or track payoffs in later episodes.</p>"""+dashboard_html(result,reviews)+"<input placeholder='Filter questions or evidence…' aria-label='Filter' oninput=\"document.querySelectorAll('article').forEach(x=>x.hidden=!x.textContent.toLowerCase().includes(this.value.toLowerCase()))\">"+(''.join(cards) or '<article>No questions were proposed. This does not prove the ending has no cliffhanger; inspect it manually.</article>')+errors+f"<p class='notice'>Run {html.escape(result['run_id'])} · {html.escape(result['pipeline_version'])}</p></main></html>"

def export_run(path):
    root=Path(path);result,episodes,reviews=load_run(root)
    rows=candidate_rows(result,reviews)
    columns=['episode','candidate_id','kind','model_question','model_status','model_answer','question','editor_decision','notes','setup_ids','reason']
    with (root/'review.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader()
        for row in rows:
            w.writerow({k: ("'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v) for k,v in row.items()})
    (root/'review.html').write_text(report_html(result,episodes,reviews),encoding='utf-8')
    with (root/'episode_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(['episode','filename','candidates','errors'])
        for ep in result['episodes']:
            filename=ep['filename'];filename="'"+filename if filename.startswith(('=','+','-','@')) else filename
            writer.writerow([ep['episode_id'],filename,len(ep['candidates']),len(ep.get('errors',[]))])
    calls=[]
    for p in (root/'calls').glob('*.json'):
        c=json.loads(p.read_text())
        if 'seconds' in c:calls.append(c)
    save_json(root/'run_metrics.json',dict(episodes=len(episodes),model_candidates=sum(len(e['candidates']) for e in result['episodes']),
        wall_seconds=result.get('wall_seconds'),
        generation_calls=len(calls),generation_seconds=round(sum(c['seconds'] for c in calls),2),
        input_tokens=sum(c['input_tokens'] for c in calls),output_tokens=sum(c['output_tokens'] for c in calls),
        editor_reviewed=sum(r['editor_decision']!='unreviewed' for r in rows),
        limitation='Counts and latency only; not semantic accuracy, engagement lift, or time saved.'))
    return shutil.make_archive(str(root),'zip',str(root))

def store_review(path,candidate_id,question,decision,notes):
    root=Path(path);result,episodes,reviews=load_run(root)
    existing={c['candidate_id'] for e in result['episodes'] for c in e['candidates']}|set(reviews)
    if candidate_id not in existing:raise ValueError('Select a valid candidate')
    if decision not in ('approved','rejected','needs_review'):raise ValueError('Select an editorial decision')
    if not question.strip():raise ValueError('Question cannot be empty')
    reviews[candidate_id]=dict(reviews.get(candidate_id,{}),question=question.strip(),decision=decision,notes=notes)
    save_json(root/'human_reviews.json',reviews)
    from datetime import datetime,timezone
    with (root/'review_history.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps(dict(candidate_id=candidate_id,at=datetime.now(timezone.utc).isoformat(),**reviews[candidate_id]))+'\n')
    return export_run(root)

def add_manual(path,episode_id,kind,question,ids,notes):
    root=Path(path);result,episodes,reviews=load_run(root)
    ep=next((e for e in episodes if e['episode_id']==int(episode_id)),None)
    if not ep:raise ValueError('Invalid episode')
    chosen=[s.strip() for s in re_split(ids) if s.strip()]
    if not chosen or set(chosen)-{b['id'] for b in ep['blocks']}:raise ValueError('Enter real passage IDs from this episode')
    if kind not in ('decision','identity','danger','other'):raise ValueError('Invalid category')
    if not question.strip():raise ValueError('Enter a question')
    from uuid import uuid4
    cid='MANUAL_'+uuid4().hex[:10]
    reviews[cid]=dict(source='human_added',episode_id=ep['episode_id'],kind=kind,question=question.strip(),
                      setup_ids=list(dict.fromkeys(chosen)),decision='approved',notes=notes)
    save_json(root/'human_reviews.json',reviews)
    store_review(root,cid,question,'approved',notes)
    return cid

def re_split(s):
    import re
    return re.split(r'[,;\s]+',s)
