ACTUAL EARLIER MODEL OUTPUTS, UNEDITED
These are the six synthetic supplied-question controls from the user-run revival-1.1 diagnostic. They are not results of desk-2.0, not full-script cliffhanger-discovery scores, and not the eight new development fixtures. Confidential real-script calls and input files are excluded.
