"""CPU engineering checks. Stubbed LLM replies are NOT model accuracy results."""
import copy,json,tempfile,unittest,zipfile
from pathlib import Path
from jsonschema import validate
from inputs import load_inputs,plain_episode,validate_episode,chunks
from backend import parse_json,repeating
from pipeline import aggregate,question_for,run_project,extract
from reports import load_run,store_review,add_manual,candidate_rows
from evaluation import demo_episodes

class StubBackend:
    def structured(self,task,payload,schema,label,run_dir):
        if label.endswith('_extract'):
            value={'items':[dict(kind='decision',subject='Ren',predicate='accept command',state_at_end='open',setup_ids=['B001'],answer_ids=[])]}
        else:
            value=dict(support='supported',resolution='unanswered',answer_polarity='none',answer='',evidence_ids=['B001'],reason='The offer is made; no response is shown.')
        validate(value,schema)
        return value

class EngineeringTests(unittest.TestCase):
    def test_plain_no_invented_times(self):
        ep=validate_episode(plain_episode('A speaks.\nB waits.',1,'demo.txt'))
        self.assertEqual(ep['format'],'plain');self.assertIsNone(ep['duration'])
    def test_zip_read_without_extraction(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'scripts.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('../../episode_002.txt','A offers B a key.\nB waits.')
            eps=load_inputs([str(p)]);self.assertEqual(eps[0]['episode_id'],2)
            self.assertEqual(len(list(Path(d).iterdir())),1)
    def test_conflicting_episode_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            paths=[]
            for name,text in [('episode_2.txt','Hello'),('ep-2.txt','Goodbye')]:
                p=Path(d)/name;p.write_text(text);paths.append(str(p))
            with self.assertRaises(ValueError):load_inputs(paths)
    def test_missing_selection(self):
        with self.assertRaises(ValueError):load_inputs(text='Hello',episode_ids=[3])
    def test_empty_input(self):
        with self.assertRaises(ValueError):load_inputs()
    def test_chunk_complete_coverage(self):
        blocks=plain_episode('\n'.join('x'*80 for _ in range(12)),1,'demo')['blocks']
        parts=chunks(blocks,300)
        self.assertEqual({b['id'] for p in parts for b in p},{b['id'] for b in blocks})
        self.assertGreater(len(parts),1)
    def test_no_partial_json_salvage(self):
        with self.assertRaises(ValueError):parse_json('{"items": [')
        self.assertEqual(parse_json('```json\n{"items": []}\n```'),{'items':[]})
    def test_repetition_stop(self):
        self.assertTrue(repeating(list(range(32))*8))
        self.assertFalse(repeating(list(range(300))))
    def test_atomic_question(self):
        self.assertEqual(question_for(dict(kind='identity',subject='the traveler',predicate='Queen Selene')),'Is the traveler Queen Selene?')
        with self.assertRaises(ValueError):question_for(dict(kind='identity',subject='the traveler',predicate='Queen Selene and why is she here'))
    def test_conflicting_answers_go_to_review(self):
        answers=[dict(support='supported',resolution='answered',answer_polarity=p,answer=p) for p in ('yes','no')]
        self.assertEqual(aggregate(answers)['status'],'needs_review')
    def test_resolved_beats_no_answer_in_other_chunk(self):
        replies=[dict(support='supported',resolution='unanswered',answer_polarity='none',answer=''),dict(support='supported',resolution='answered',answer_polarity='no',answer='No')]
        self.assertEqual(aggregate(replies)['status'],'resolved_in_episode')
    def test_reports_review_preserves_original(self):
        with tempfile.TemporaryDirectory() as d:
            cfg=dict(output_root=d,ending_seconds=45,plain_ending_blocks=12,verification_chunk_chars=9000,max_verification_chunks=6)
            path=run_project(StubBackend(),demo_episodes()[:1],cfg)
            original=(Path(path)/'results.json').read_bytes()
            result,eps,_=load_run(path);c=result['episodes'][0]['candidates'][0]
            self.assertEqual(c['setup_ids'],['E101_B0001'])
            self.assertEqual(c['verification'][0]['evidence_ids'],['E101_B0001'])
            self.assertTrue(c['coverage_complete'])
            store_review(path,c['candidate_id'],'Will Ren accept the command?','approved','Checked the offer.')
            add_manual(path,101,'other','Will someone interrupt?',eps[0]['blocks'][0]['id'],'Human example; not a model prediction.')
            self.assertEqual(original,(Path(path)/'results.json').read_bytes())
            self.assertTrue(Path(path+'.zip').exists())
            _,_,reviews=load_run(path);self.assertEqual(len(candidate_rows(result,reviews)),2)
    def test_schema_grammar_accepts_bounded_json(self):
        from lmformatenforcer import JsonSchemaParser
        schema={'type':'object','properties':{'answer':{'type':'string','maxLength':12}},'required':['answer'],'additionalProperties':False}
        parser=JsonSchemaParser(schema)
        for char in '{"answer":"No"}':
            self.assertIn(char,parser.get_allowed_characters());parser=parser.add_character(char)
        self.assertTrue(parser.can_end())
    def test_mixed_thinking_modes(self):
        from backend import QwenBackend
        backend=QwenBackend({'thinking':True,'verification_thinking':False})
        self.assertTrue(backend.thinking_for('E003_extract',0))
        self.assertFalse(backend.thinking_for('E003_H1_verify_1',0))
        self.assertFalse(backend.thinking_for('E003_extract',1))
        backend.cfg['verification_thinking']=True
        self.assertTrue(backend.thinking_for('E003_H1_verify_1',0))

    def test_zero_candidates_still_exports_episode(self):
        import csv
        class NoHooks:
            def structured(self,*args):return {'items':[]}
        with tempfile.TemporaryDirectory() as d:
            cfg=dict(output_root=d,ending_seconds=45,plain_ending_blocks=12,verification_chunk_chars=9000,max_verification_chunks=6)
            path=Path(run_project(NoHooks(),demo_episodes()[:1],cfg))
            rows=list(csv.DictReader((path/'episode_summary.csv').open(encoding='utf-8-sig')))
            self.assertEqual(len(rows),1);self.assertEqual(rows[0]['candidates'],'0')
            self.assertEqual(len(list(csv.DictReader((path/'review.csv').open(encoding='utf-8-sig')))),0)

    def test_gradio_builds_without_loading_model(self):
        from app import make_app
        app=make_app({'output_root':'runs','input_dir':'inputs','episode_ids':[]})
        self.assertGreater(len(app.blocks),20)
        self.assertTrue(any(c['type']=='file' for c in app.config['components']))
        self.assertTrue(any(c['type']=='dropdown' for c in app.config['components']))

    def test_gradio_review_workflow(self):
        import asyncio
        from app import make_app
        from gradio.state_holder import SessionState
        from evaluation import CASES
        async def exercise():
            with tempfile.TemporaryDirectory() as d:
                cfg=dict(output_root=d,input_dir='inputs',episode_ids=[],ending_seconds=45,plain_ending_blocks=12,verification_chunk_chars=9000,max_verification_chunks=6)
                app=make_app(cfg,StubBackend());session=SessionState(app)
                response=await app.process_api(1,[None,CASES[0]['text'],2,45,''],state=session)
                while response.get('is_generating'):
                    response=await app.process_api(1,[],state=session,iterator=response['iterator'])
                state_id=next(k for k,b in app.blocks.items() if b.__class__.__name__=='State')
                path=session[state_id]
                result=json.loads(Path(path,'results.json').read_text())
                cid=result['episodes'][0]['candidates'][0]['candidate_id']
                selected=await app.process_api(3,[None,cid],state=session)
                self.assertIn('Will Ren accept command?',selected['data'][0])
                await app.process_api(4,[None,cid,'Will Ren accept command?','approved','Checked.'],state=session)
                self.assertEqual(json.loads(Path(path,'human_reviews.json').read_text())[cid]['decision'],'approved')
                full=await app.process_api(5,[None,'1000'],state=session)
                self.assertIn('Commander Vale',full['data'][0])
                await app.process_api(6,[None,'1000','decision','Will Ren join the team?','E1000_B0001','Human test.'],state=session)
                self.assertEqual(len(json.loads(Path(path,'human_reviews.json').read_text())),2)
                self.assertTrue(Path(path+'.zip').exists())
        asyncio.run(exercise())

if __name__=='__main__':unittest.main(verbosity=2)
