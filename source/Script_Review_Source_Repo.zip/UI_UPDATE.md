# Script Review — presentation update

The product name is Script Review. This is a UI and challenge-library update on desk-2.1; model weights, extraction prompts and verification settings are unchanged. Ten challenge cases and a semantic review rubric are added. The Test lab automatic button still runs only the eight standard category checks. No accuracy claim is made for the challenge cases.

Restart the old app and launch this notebook. In Analyze, choose a challenge demo and click Load demo text. Remove uploaded files and clear the episode-ID filter before analyzing a pasted demo. Use Analyze uploaded / pasted scripts for demos and app uploads, or Analyze attached Kaggle dataset for Kaggle inputs.

Review one successful and one failed example in the interview. Explain corrections as human editorial review; do not represent edited questions as original model output. A previously observed character-identity swap remains a known failure mode; the first challenge tests it. This update does not claim to fix that model error.

Historical solution PDFs retain the earlier product name and validation history. They are not a report of this UI release or its GPU quality.
