import argparse,json,subprocess,sys
from pathlib import Path
from backend import QwenBackend
from inputs import dataset_paths,load_inputs
from evaluation import demo_episodes,run_evaluation
from pipeline import run_project

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',required=True)
    parser.add_argument('--evaluate',action='store_true');args=parser.parse_args()
    cfg=json.loads(Path(args.config).read_text());backend=QwenBackend(cfg)
    if args.evaluate:path,_=run_evaluation(backend,cfg)
    else:
        if cfg['input_mode']=='demo':episodes=demo_episodes()
        elif cfg['input_mode']=='dataset':episodes=load_inputs(dataset_paths(cfg['input_dir']),limit=cfg['max_episodes'],episode_ids=cfg['episode_ids'])
        else:raise ValueError('input_mode must be demo or dataset')
        print('INPUT MODE:',cfg['input_mode'],'EPISODES:',[(e['episode_id'],len(e['blocks'])) for e in episodes],flush=True)
        path=run_project(backend,episodes,cfg)
    root=Path(path)
    (root/'requirements-resolved.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
    from reports import export_run
    archive=export_run(root)
    Path(cfg['output_root']).mkdir(parents=True,exist_ok=True)
    (Path(cfg['output_root'])/'latest_run.txt').write_text(path)
    print('RESULTS:',path,'\nDOWNLOAD ZIP:',archive,flush=True)
    print((root/'results.json').read_text(),flush=True)
if __name__=='__main__':main()
